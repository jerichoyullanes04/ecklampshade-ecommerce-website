<footer class="footer">

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>Online Lamp Store</span> | all rights reserved!</div>

</footer>